# Lesson 02a Task — ANSWER KEY / TEACHING NOTES
**DO NOT DISTRIBUTE TO STUDENTS**

Student answers will vary (they choose their own animals/images). Look for:

**Setup / tables:** Complete tables with real confidence percentages (e.g., "87% cat"). Any two
distinct classes and 3–5 starting images are fine.

**Q5–Q8 (the heart of the lab):**
- **Q5:** Any honest answer with evidence from their table.
- **Q6:** Good answers connect accuracy to training data — a model may be "100%" because the test
  images looked a lot like the training images (or the two animals are very different). Struggles
  usually come from unusual angles, lighting, backgrounds, or animals that look similar.
- **Q7:** Expected pattern: **more (and more varied) training data usually raises confidence /
  accuracy.** Accept "it stayed the same" if their starting model was already strong — but they
  should notice the trend.
- **Q8:** Strong answers: add more images, add more *varied* images (angles, lighting,
  backgrounds), remove misleading images, add classes carefully.

**Vocabulary:**
9. **class**
10. **supervised**

**Teaching tip:** The whole point is to build intuition that ML = learn-from-labeled-examples and
that **data quality/quantity drives accuracy** — the through-line for decision trees, random
forests, and neural networks later this year.
