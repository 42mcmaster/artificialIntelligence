# Lesson 09a Task — ANSWER KEY / TEACHING NOTES
**DO NOT DISTRIBUTE TO STUDENTS**

Exact numbers vary by run; grade on correct *trends* and reasoning.

- **Q1–Q2:** Two blobs are linearly separable — even a tiny net solves it fast (often < 100 epochs),
  output cleanly split (Y).
- **Q3–Q4:** The spiral is **not** linearly separable. A 2-neuron network **cannot** solve it (N).
  Good reasoning: too few neurons/layers means too little capacity to bend the decision boundary
  into a spiral; it can only draw simple (nearly straight) boundaries.
- **Q5–Q6:** Any reasonable larger setup works — typically **2 hidden layers, 6–8 neurons each**,
  often helped by extra features (x1², x2², sin). Lowest test loss usually well under 0.1.
- **Q7:** Tiny learning rate (0.0001) => learns **very slowly**; loss barely moves in the time given.
- **Q8:** Huge learning rate (3) => **unstable**; loss bounces around / spikes / never settles.
- **Q9:** Learning rate controls **how big each weight adjustment (step) is** during training.
- **Q10–Q11:** With high noise + little training data, **Training loss << Test loss** (Y). The gap
  means **overfitting**: the model memorized noisy training points instead of the real pattern.
- **Q12 (matching):**
  - Neurons/layers -> `hidden_layer_sizes=(8, 8)`
  - Activation -> `activation='relu'`
  - Learning rate -> `learning_rate_init=...`
  - Epochs -> `max_iter=...`

**Teaching tip:** This lesson makes underfitting/good-fit/overfitting *visible* before students
meet them as numbers in ai10. Emphasize the last table — every knob here is a real
`MLPClassifier`/`MLPRegressor` argument next lesson.
